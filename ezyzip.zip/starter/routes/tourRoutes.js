const express = require('express');
const fs = require('fs');

const app = express();
const tourController = require('../controllers/tourController');

//////////

// CONTROLLERS==ROUTEHANDLERS


const router = express.Router();

//router.param('id',tourController.checkID);
//router.param("name",tourController.checkBody);

//app.get('/api/v1/tours',getAllTours);





 // router.get('/:id',tourController.getOneTour );
   // router.post('/:id',tourController.postNewTour);

//////////////////////////PATCH

  //  router.patch('/:id',updateTour);
  //  router.delete('/:id',deleteTours);
 /////////////////////////////////////////////////////
     router.route('/')
    .get(tourController.getAllTours)
    //.post(tourController.checkBody,tourController.postNewTour)
    .post(tourController.createTour)
    

     router.route('/:id')
     .patch(tourController.UpdateTour)
    .delete(tourController.deleteTours)
     //.get(tourController.getOneTour)


 

 module.exports = router;
