const fs= require("fs");

const express = require("express");

const mongodb = require("mongodb");

const MongoClient = mongodb.MongoClient();



const mongoose = require('mongoose');
const dotenv = require('dotenv');

const tourController = require('../../controllers/tourController');


dotenv.config();
const Tour = require("../../Models/tourModel");

console.log("yes");

const app = require("../../app");


const DB = "mongodb+srv://aniharika:Allasai123@clusterabc.br3lw.mongodb.net/natours?retryWrites=true&w=majority";
console.log(DB);


//mongoose.Promise = global.Promise;


mongoose
//.connect(process.env.DATABASE_LOCAL, {
.connect(DB, {
    useNewUrlParser: true,
    useCreateIndex: true,
    useFindAndModify: false,
    useUnifiedTopology: true
  })
  // .then((con) => {
  //   console.log(con.connections);
  .then(() => {

  console.log('DB connection successful!')})
  .catch((err)=> console.log(err));
 


  const tours = JSON.parse(fs.readFileSync("tours-simple.json", "utf-8"));

   ///  IMPORT DATA INTO DB

   const importData =async () =>{
       try{  await Tour.create(tours);
        console.log("Data loaded!!!");

       }catch(err){
           console.log(err);
       }
   }

   //Delete all data from collections

   const deleteData = async ()=>{
       try{


        await Tour.deleteMany();
        console.log("Data Deleted!!");
       }catch(err){
        console.log(err);

       }
   }


   console.log(process.argv);


   if(process.argv[2] === '--import'){
       importData();
   }
   else if(process.argv[2] === '--delete'){
       deleteData();
     // console.log(tourController.getAllTours);
     

   }

   //calling functions to run
   //deleteData();
   //importData();

   const port =3000;
app.listen(port, () => {
    console.log(`App running on port ${port}...`);
  });
