const fs = require('fs');





exports.getAllUsers = (req,res)=>{
    res.status(500)
    .json({
        status:"hello",
        message:"Whever"
    });
    
    }

    exports.getOneUser = (req,res)=>{
        res.status(500)
        .json({
            status:"hello",
            message:"Whever"
        });
        
        }


    
    
    exports.createUser = (req,res)=>{

        res.status(500)
        .json({
            status:"hello",
            message:"Whever"
        });
    

    }

    
    exports.updateUser = (req,res)=>{
        console.log("hello");
        res.status(500)
        .json({
            status:"hello",
            message:"Whever"
        });
    


    }

    
    exports.deleteUser = (req,res)=>{
        res.status(500)
        .json({
            status:"hello",
            message:"Whever"
        });
    


    }