/* eslint-disable node/no-unsupported-features/es-syntax */
const express = require('express');
const fs = require('fs');
const { compile } = require('morgan');
//const { delete } = require('../app');
//const tourController = require('../../../../../complete-node-bootcamp-master/4-natours/after-section-08/controllers/tourController');

const router = express.Router();

const Tour= require('../Models/tourModel');

// const newTour = new Tour({})
// newTour.save();





exports.createTour = async (req,res)=>{




try{
 const newTour = await Tour.create(req.body);


  res.status(201).json({
    status : "Success",
    data: {
      tour : newTour
    }
});

} catch(err) {
  console.log("ERROR IS COMING");
  res.status(400).json({
  status :"fail",
  message : err
  });
}





};

///GET ALL TOURS
exports.getAllTours =async (req,res)=>{
 try{


//BUILD QUERY   
const queryObj = { ...req.query};  


// const excludeFields = ['page', 'limit', 'fields'];
// excludeFields.forEach(el => delete queryObj[el]);


//EXECUTE QUERY

let queryStr = JSON.stringify(queryObj);
 
 queryStr= queryStr.replace(/\b(gte|gt|lte|lt)\b/g , match => `$${match}`);

 console.log(JSON.parse(queryStr));
 
 let query =Tour.find(JSON.parse(queryStr));
 //console.log(typeof(query));//
//console.log("yes",query.sort());



//duration :5,
   //difficulty : "easy"
 //});
 
 // SORTING
 if (req.query.sort) {
 console.log(typeof(req.query.sort));
  query = query.sort(req.query.sort); 
  //(req.query.sort);
}
//////////////FIELDS
if(req.query.fields){
  const fields =req.query.split(",").join(" ");
  query = query.select(fields);
}
else{
  query=query.select("-__v");
}












 //EXECUTE QUERY
 const tours =  await query;

 console.log("Hie",tours);
 
 

//console.log(req.query);
res.status(200).json({
 status : "Success",
 results : tours.length,
 data: {
   tours
 }



});
 } catch(err){
   
   res.status(404).json({
     status:"fail",
     result:"check and correct data"
   })
 }
 console.log(req.query);
 
 //console.log("HELLOO");


};






//const tours = JSON.parse(fs.readFileSync(`${__dirname}/../dev-data/data/tours-simple.json`, 'utf-8'));
//


// app.post('/', (req,res)=>{
//     res.send("POST STUFF");
// });
// exports.checkBody = (req,res,next)=>{
  //   console.log("Tour name not there");
//
  //   if(req.body.price==null){
    //return res.status(404).json({status:"No name or body"});
     //}

 //    next();
 //}



//exports.checkID = (req,res, next, val)=>{
  //   console.log(`Tour value is ${val}`);
    //  if(req.params.id*1 > tours.length)
    //     {
    //         return res.status(404).json({status:"Not found"});
    //     }
    //     next();
       
 //}
/////////////////////////////////////////////////////////////////////////////////////





////////////////////////
//  exports.getAllTours= (req,res)=>{
//     res
//      .status(200)
//      .json({
//          status:'success',
//        // result:tours.length,
//         time:req.requestTime,
//         data: {
//           //  tours : tours
//         }
//     });
// }

/*exports.getOneTour = async (req,res)=>{
    // const id = parseInt(req.params.id);
    try{

      const tour = await Tour.findById(req.params.id);
     // Tour.findOne({_id : req.params.id});  //-->this will work as well

      res.status(200).json({
        status : "Success",
        data : {
          tour
        }


      })

      //const id = req.params.id * 1;


    }catch(error){
      res.status(404).json({
        status:"fail",
        result:"check and correct data"
      });
    };
    
    
    
    
    
    
   // const tour = tours.find(el => el.id ===id);


    // if(id >= tours.length)
    //Alternativ
    // if(!tour)
    // {return res.status(404).json({status:"Not found"});
    // }
     //else{

     //   console.log(req.params);
       // res.status(200)
        //.json({
          //  status:'success',
            //data: {
              //   tour
            //}
        //});
    
    
    //}


    


    //const id = req.params.id*1;  ///This can also be used instead
    



}
*/

// exports.postNewTour = (req,res)=>{

//     // console.log(req.body);
    
//     const newid = tours[tours.length-1].id+1;

//     const obj = {
//         id : newid

//     }
//     const newTour = obj.assign({ id: newid }, req.body);
    
//     console.log(JSON.stringify(newTour));
    
    
    
//      tours.push(newTour);
//     //  //console.log(JSON.stringify(tours));
    //  //const tour1=JSON.stringify(tours);
    /* 
    //fs.writeFile(`${__dirname}/../dev-data/data/tours-simple.json`, JSON.stringify(tours), err=>{
      res
     .status(201)
     .json({
              status:"success",
         data: {
                  tour: newTour
           }
      });
    // //res.send("!");
     });
    }
*/


   // exports.updateTour= (req,res)=>{
//
  //      console.log("Hello");
    
    //    if(req.params.id*1 > tours.length)
    //    {
    //        return res.status(404).json({status:"Not found"});
    //    }
        
    
        // else{
    
        
        // res.status(200).json({
          //   status:"success",
        //     message:"Updated text Input"
      //   });
        // }
  //  } 



    exports.deleteTours = async (req,res)=>{

      try{
        const tour = await Tour.findByIdAndDelete(req.params.id );
       res.status(200).json({
          status: "Success",
          data : {
             tour
          }
     
        });
       } catch(err){
         res.status(404).json({
           status:"fail",
           result:"check and enter correct data"
         });
       };
     




        // if(req.params.id*1 > tours.length)
        // {return res.status(404).json({status:"Not found"});
        // }
         
     
        // //   else{
        //      console.log("Hello");
     
         
        //   res.status(204).json({
        //       status:"success",
        //       data:{
        //           message:null
        //   //    }
        //      });
          }
   //  }
   ///////////////////////////////////////////////////////////////////


   exports.UpdateTour = async (req,res)=>{
  
  
    try{
     const tour = await Tour.findByIdAndUpdate(req.params.id,req.body, {
        new : true,
        runValidators : true
      })
    res.status(200).json({
       status: "Success",
       data : {
          tour
       }
  
     });
    } catch(err){
      res.status(404).json({
        status:"fail",
        result:"check and enter correct data"
      });
    };
  
  }
  
  
  
  
  