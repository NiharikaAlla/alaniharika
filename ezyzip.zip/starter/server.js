
const express = require("express");


const mongodb = require("mongodb");

const MongoClient = mongodb.MongoClient();
const mongoose = require('mongoose');


const dotenv = require('dotenv');
 
dotenv.config();
const app = require('./app');




const DB = process.env.DATABASE.replace('<password>',"Allasai123");
console.log(process.env.DATABASE_LOCAL);


//mongoose.Promise = global.Promise;


mongoose
//.connect(process.env.DATABASE_LOCAL, {
.connect(DB, {
    useNewUrlParser: true,
    useCreateIndex: true,
    useFindAndModify: false,
    useUnifiedTopology: true
  })
  // .then((con) => {
  //   console.log(con.connections);
  .then(() => {

  console.log('DB connection successful!')})
  .catch((err)=> console.log(err));


//console.log(req.query);



/*
const testTour = new Tour({
//  name : "The forest Hiker",
//  price : 540,
//  rating : 5 

name :"The whatever",
price : 25

});

testTour.save().then(()=>console.log("Saved Document")).catch((err)=>{
  console.log(err);
});

*/
//console.log(process.env);





const port =3000;
app.listen(port, () => {
    console.log(`App running on port ${port}...`);
  });
  