const mongoose = require('mongoose');
////////////////////

/////SCHEMA AND MODELS/// MONGOOSE PART OF TUTORIAL

const toursSchema = new mongoose.Schema({
    name :{
      type : String,
      required : [true,"A name must be given"], //validator
      unique  :[true,"A name must be unique"]
    },
    duration:{
     type: Number,
     required : [true,"Duration must be given"]
    },
    maxGroupSize: {
      type: Number,
      required : [true,"maxGroupSize must be given"]
     },
     difficulty:{
      type: String,
      required : [true,"Difficulty must be given"]
     },
    
    //rating : Number,
    ratingsAverage : {
      type : Number,
      default :4.5
      },
      
      ratingsQuantity : {
    type : Number,
    default :0
    },
    
    price : {
      type : Number,
      required : [true, "A tour must have a price"]
    },
    priceDiscount : Number,
    summary : {
     type: String,
     trim : true,
     required : [true, "A tour must have a description"]

    },
    description :  {
      type :String,
      trim : true
    },
    imageCover :  {
      type :String,
      trim : true,
      required : [true, "A tour must have a image cover"]

    },

    images : [String],
    createdAt : {
      type : Date,
      default :Date.now()
    },

    startDates : [Date]
    
    
    
    
    
    });
    
    
    const Tour = mongoose.model('Tour',toursSchema);
    module.exports = Tour;
    